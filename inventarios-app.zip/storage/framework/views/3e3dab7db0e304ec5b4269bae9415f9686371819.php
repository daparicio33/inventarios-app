
<?php $__env->startSection('title', 'Encargados'); ?>
<?php $__env->startSection('content_header'); ?>
<h1><i class="fab fa-black-tie"></i> Encargados</h1>
    <a href="<?php echo e(route('administrador.almacenes.encargados.create')); ?>">
        <button class="btn btn-primary"> 
            <i class="fas fa-folder-open"></i> Nuevo Encargado
        </button>
    </a>
    <?php echo $__env->make('layouts.info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h3><p>Lista de encargados</p></h3>
    <table class="table">
        <thead>
            <tr>
                <th><i class="fas fa-user"></i>  Nombre de usuario</th>
                <th><i class="fab fa-black-tie"></i>  Cargo del usuario</th>
                <th><i class="fab fa-buffer"></i>  Almacen</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $encargados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encargado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($encargado->user->name); ?></td>
                    <td><?php echo e($encargado->cargo->nombre); ?></td>
                    <td><?php echo e($encargado->almacene->nombre); ?></td>
                    <td style="width: 130px; text-align: center">
                        <a title="editar" href="<?php echo e(route('administrador.almacenes.encargados.edit',$encargado->id)); ?>" class="btn btn-success">
                            <i class="far fa-edit"></i>
                        </a>
                        <a title="eliminar" class="btn btn-danger" data-toggle="modal" data-target="#modal-delete-<?php echo e($encargado->id); ?>">
                            <i class="fas fa-trash-alt"></i>
                        </a>
                        
                    </td>
                </tr>
                <?php echo $__env->make('administrador.almacenes.encargados.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\inventarios-app\resources\views/administrador/almacenes/encargados/index.blade.php ENDPATH**/ ?>