
<?php $__env->startSection('title', 'Almacenes'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Almacenes</h1>
    <a href="<?php echo e(route('administrador.almacenes.create')); ?>">
        <button class="btn btn-primary">
            <i class="fas fa-plus"></i> Nuevo almacen
        </button>
    </a>
    <?php echo $__env->make('layouts.info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="table-responvise">
<table class="table">
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Observacion</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $almacenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $almacene): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($almacene->nombre); ?></td>
                <td><?php echo e($almacene->observacion); ?></td>
                    <td style="width: 130p; text-align: center">
                        <a title="Editar" href="<?php echo e(route('administrador.almacenes.edit',$almacene->id)); ?>" class="btn btn-primary">
                            <i class="fas fa-pen"></i>
                        </a>
                        <button title="Eliminar" type="button" class="btn btn-danger" data-toggle="modal" data-target="#modal-delete-<?php echo e($almacene->id); ?>">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
            </tr>
            <?php echo $__env->make('administrador.almacenes.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\inventarios-app\resources\views/administrador/almacenes/index.blade.php ENDPATH**/ ?>