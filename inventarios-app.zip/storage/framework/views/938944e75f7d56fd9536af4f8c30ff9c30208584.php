<?php $__env->startSection('title', 'Inventarios'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="text-danger">Sistema de Inventarios</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>Bienvenido al sistema de Gestion de Inventarios.</p>
    <small>Sistema Desarrollado por:
        <ul>
            <li>Aparicio Palomino Davis Williams - <b>Supervisor del Proyecto</b></li>
            <li>Llaja Huaman Neymer Jesus</li>
            <li>Valqui Puerta Dilberth</li>
            <li>Acuña Chavez Dante Miguel</li>
            <li>Pinzón Hernández Fernanda Elizabeth</li>
            <li>Yoplac Muñoz Kevin Alexis</li>
            <li>Campojo Mas Luis Antonio</li>
            <li>Chota Mas Edwin Maycol</li>
            <li>Pilco Mas Waldir</li>
            <li>Medina Muñoz José Antonio </li>
        </ul>

    </small>
    <p class="font-italic">Todos los derechos reservados al Laboratorio de Programacion IDEX Perú Japón - 2022</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\inventarios-app\resources\views/welcome.blade.php ENDPATH**/ ?>