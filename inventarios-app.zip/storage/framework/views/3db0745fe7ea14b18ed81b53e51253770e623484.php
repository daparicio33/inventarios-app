<?php echo Form::open(["route"=>["inventarios.movimientos.destroy",$movimiento->id],"method"=>"delete"]); ?>

<div class="modal fade" id="modal-delete-<?php echo e($movimiento->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-danger" id="exampleModalLabel">
          <i class="far fa-question-circle"></i> Confirmar
        </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Esta seguro que desea eliminar el movimiento # <b><?php echo e($movimiento->numero); ?></b>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">
          <i class="fas fa-times"></i> Cerrar
        </button>
        <button type="submit" class="btn btn-danger">
          <i class="fas fa-trash"></i> Eliminar
        </button>
      </div>
    </div>
  </div>

</div>
<?php echo Form::close(); ?>

<div class="modal fade" id="modal-mostrar-<?php echo e($movimiento->id); ?>" tabindex="-2" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title text-info" id="exampleModalLabel">
            <i class="fas fa-clipboard-list"></i> Lista de Detalles
          </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-sm-1 bg-secondary pt-2 pb-2">
              
            </div>
            <div class="col-sm-2 bg-secondary pt-2 pb-2">
              <b>Cant.</b>
            </div>
            <div class="col-sm-9 bg-secondary pt-2 pb-2">
              <b>Descripcion</b>
            </div>
            <?php $__currentLoopData = $movimiento->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-sm-1 pt-1 pb-1">
                <?php echo Form::open(['route'=>['inventarios.movimientos.detalles.destroy',$detalle->id],'method'=>'delete']); ?>

                <button class="btn btn-danger" type="submit" title="eliminar">
                  <i class="far fa-trash-alt"></i>
                </button>
                <?php echo Form::close(); ?>

              </div>
              <div class="col-sm-2 pt-1 pb-1 d-flex align-items-center">
                <?php echo e($detalle->cantidad); ?>

              </div>
              <div class="col-sm-9 pt-1 pb-1 d-flex align-items-center">
                <?php echo e($detalle->item->titem->nombre); ?> - <?php echo e($detalle->item->marca->nombre); ?> - <?php echo e($detalle->item->descripcion); ?>

              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-info" data-dismiss="modal">
            <i class="fas fa-times"></i> Cerrar
          </button>
        </div>
      </div>
    </div>
  </div>




<?php /**PATH C:\Users\Dave\Desktop\inventarios-app\resources\views/inventarios/movimientos/modal.blade.php ENDPATH**/ ?>