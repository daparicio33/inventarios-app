
<?php $__env->startSection('title', 'Editar Encargado'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1 class="text-primary"><i class="fas fa-marker"></i> Editar encargado</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo Form::model($encargado, ['route'=>['administrador.almacenes.encargados.update',$encargado->id],'method'=>'PUT','enctype'=>'multipart/form-data']); ?>

    <div class="row">
        <div class="col-sm-12 col-md-9 col-lg-9">
            <div class="card">
                <div class="card-header">
                    <h5><i class="fas fa-list-alt"></i> Datos del Producto</h5>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="">
                            <i class="fas fa-user"></i>  Nombre de usuario
                        </label>
                        <?php echo Form::select('user_id', $users, null, ['class'=>'form-control']); ?>

                        <label for="">
                            <i class="fab fa-black-tie"></i>  Cargo del usuario
                        </label>
                        <?php echo Form::select('cargo_id', $cargos, null, ['class'=>'form-control']); ?>

                        <label for="">
                            <i class="fab fa-buffer"></i>  Almacen
                        </label>
                        <?php echo Form::select('almacene_id', $almacenes, null, ['class'=>'form-control']); ?>

                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Guardar
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\inventarios-app\resources\views/administrador/almacenes/encargados/edit.blade.php ENDPATH**/ ?>