
<?php $__env->startSection('title', 'Movimientos'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Movimientos de Almacen</h1>
    <a href="<?php echo e(route('almaceneros.create')); ?>">
        <button class="btn btn-primary"> 
            <i class="fas fa-paper-plane"></i> Nuevo
        </button>
    </a>
    <?php echo $__env->make('layouts.info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="table-responsive">
    <table class="table table-striped" style="white-space: nowrap; overflow-x: auto;">
        <thead>
            <tr>
                <th>#</th>
                <th>Tipo</th>
                <th>Fecha</th>
                <th>Hora</th>
                <th>Cliente</th>
                <th>Usuario</th>
                <th>F. Devolucion</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $movimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr <?php if($movimiento->movimiento_id == null): ?> class="text-danger" <?php else: ?> class="bg-secondary" <?php endif; ?>>
                    <td><?php echo e(ceros($movimiento->numero)); ?></td>
                    <td><?php echo e($movimiento->tmovimiento->nombre); ?></td>
                    <td><?php echo e(date('d-m-Y',strtotime($movimiento->fecha))); ?></td>
                    <td><?php echo e($movimiento->hora); ?></td>
                    <td><?php echo e($movimiento->cliente->apellido); ?>, <?php echo e($movimiento->cliente->nombre); ?></td>
                    <td><?php echo e($movimiento->user->email); ?></td>
                    <td><?php if(isset($movimiento->fdevolucion)): ?> <?php echo e(date('d-m-Y',strtotime($movimiento->fdevolucion))); ?> <?php endif; ?></td>
                    <td style="text-align: center; width: 160px">
                        <?php if(!isset($movimiento->movimiento_id)): ?>
                            <a data-toggle="modal" data-target="#modal-devolucion-<?php echo e($movimiento->id); ?>" title="registrar devolucion" class="btn btn-success">
                                <i class="fas fa-undo-alt"></i>
                            </a>
                            <a data-toggle="modal" data-target="#modal-mostrar-<?php echo e($movimiento->id); ?>"  title="mostrar" class="btn btn-info">
                                <i class="fas fa-eye"></i>
                            </a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('almaceneros.imprimir',$movimiento->id)); ?>" class="btn btn-warning" title="imprimir">
                            <i class="fas fa-print"></i>
                        </a>
                        <a data-toggle="modal" data-target="#modal-delete-<?php echo e($movimiento->id); ?>" class="btn btn-danger" title="eliminar">
                            <i class="fas fa-trash"></i>
                        </a>
                    </td>
                </tr>
                
                <?php if(isset($movimiento->movimiento_id)): ?>
                <tr>
                    <td></td>
                    <td colspan="7">
                        <table class="table table-striped">
                            <thead>
                                <th>#</th>
                                <th>Tipo</th>
                                <th>Fecha</th>
                                <th>Hora</th>
                                <th>Usuario</th>
                                <th></th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $movimiento->devoluciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devolucion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(ceros($devolucion->numero)); ?></td>
                                        <td><?php echo e($devolucion->tmovimiento->nombre); ?></td>
                                        <td><?php echo e(date('d-m-Y',strtotime($devolucion->fecha))); ?></td>
                                        <td><?php echo e($devolucion->hora); ?></td>
                                        <td><?php echo e($devolucion->user->email); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('almaceneros.imprimir',$devolucion->id)); ?>" class="btn btn-warning" title="imprimir">
                                                <i class="fas fa-print"></i>
                                            </a>
                                            <a data-toggle="modal" data-target="#modal-delete-devolucion<?php echo e($devolucion->id); ?>" class="btn btn-danger" title="eliminar">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $__env->make('almaceneros.devolucion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <?php endif; ?>
                <?php echo $__env->make('almaceneros.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\inventarios-app\resources\views/almaceneros/index.blade.php ENDPATH**/ ?>