
<?php $__env->startSection('title', 'Crear Item'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1 class="text-primary"><i class="fas fa-marker"></i> Crear Item</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo Form::open(['route'=>'inventarios.items.store','method'=>'post','enctype'=>'multipart/form-data']); ?>

    <div class="row">
        <div class="col-sm-12 col-md-7 col-lg-7">
            <div class="card">
                <div class="card-header">
                    <h5><i class="fas fa-list-alt"></i> Datos del Producto</h5>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="">
                            <i class="fas fa-code"></i> Código
                        </label>
                        <?php echo Form::text('codigo', null, ['class'=>'form-control']); ?>

                        <label for="" class="mt-2">
                            <i class="fas fa-stream"></i> Descripcion
                        </label>
                        <?php echo Form::textarea('descripcion', null, ['class'=>'form-control', 'rows'=>'3']); ?>

                        <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="row mt-2" id="marcatipo">
                            <div class="col-sm-12 col-md-6">
                                <label for="">
                                    <i class="fab fa-markdown"></i> Marca
                                </label>
                                <?php echo Form::select('marca_id', $marcas, null, ['class'=>'form-control','id'=>'marca_id']); ?>

                            </div>
                            <div class="col-sm-12 col-md-6">
                                <label for="">
                                    <i class="fas fa-text-height"></i> Tipo
                                </label>
                                <?php echo Form::select('titem_id', $titems, null, ['class'=>'form-control','id'=>'titem_id']); ?>

                            </div>
                        </div>
                        <div class="row mt-2">
                            <label for="">
                                <i class="fas fa-superscript"></i> Item padre
                            </label>
                            <select name="item_id" id="item_id" class="form-control" onchange="selectpadre()">
                                <option value="0" class="form-control" >Sin padre</option>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->descripcion); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Guardar
                    </button>
                </div>
            </div>
        </div>
        <div class="col-sm-12 col-md-5 col-lg-5">
            <div class="card">
                <img id='imgpreview' style="max-width: 90%" src="<?php echo e(Storage::url('public/items/defaultitem.png')); ?>" class="rounded mx-auto d-block" alt="...">
                <div class="card-body">
                    <?php if (isset($component)) { $__componentOriginal779aa8a3778a44f627a67101ca73adb528b17c70 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Form\InputFile::class, ['name' => 'url','igroupSize' => 'sm','placeholder' => 'Elija un archivo...']); ?>
<?php $component->withName('adminlte-input-file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['onchange' => 'previewimage(event,\'#imgpreview\')']); ?>
                         <?php $__env->slot('prependSlot', null, []); ?> 
                            <div class="input-group-text bg-primary">
                                <i class="fas fa-upload"></i>
                            </div>
                         <?php $__env->endSlot(); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal779aa8a3778a44f627a67101ca73adb528b17c70)): ?>
<?php $component = $__componentOriginal779aa8a3778a44f627a67101ca73adb528b17c70; ?>
<?php unset($__componentOriginal779aa8a3778a44f627a67101ca73adb528b17c70); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            $('#marca_id').select2();
            $('#titem_id').select2();
            $('#item_id').select2();
        });
        function selectpadre (){
            let sel = document.getElementById('item_id');
            let marcatipo = document.getElementById('marcatipo');
            if (sel.value == 0){
                marcatipo.style.display = 'flex';
            }else{
                marcatipo.style.display = 'none';
            }
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\inventarios-app\resources\views/inventarios/items/create.blade.php ENDPATH**/ ?>