
<?php $__env->startSection('title', 'Usuarios'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Usuarios</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<style>
  #foto{
    border: 1px solid rgba(17, 2, 71, 0.623)55, 34, 34);
    border-radius: 40px;
    height: 40px;
    width: 40px;
  }
</style>
<div class="container">
  <div class="row">
      <div class="col-sm-6 col-lg-12">
          <button id="nuevo" class="btn btn-primary" type="button" data-toggle='modal' data-target='#modalcreate' ><i class="fas fa-plus"></i>
          Nuevo</button>    
      </div>    
  </div>       
</div>
<?php echo $__env->make('administrador.usuarios.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
      <div class="col-sm-6 col-md-6 col-lg-10 mx-auto">
        <table class="table">
          <thead>
            <tr>
              <th>Foto</th>
              <th>Nombre</th>
              <th>Correo</th>
              <th style="text-align:center">Opciones</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><img id="foto" <?php if(isset($user->url)): ?> src="<?php echo e(Storage::url($user->url)); ?>" <?php else: ?> src="<?php echo e(Storage::url('public/userspics/defaultPic.png')); ?>" <?php endif; ?>></td>
                <td style="width: 250px"><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td style="text-align:center">
                  <div class="btn-group mx-auto">
                    <button type="button" data-toggle='modal' data-target='#modaledit<?php echo e($user->id); ?>' class="btn btn-primary btn-sm"><i class="fas fa-pen-nib"></i></button>
                    <button type="button" data-toggle='modal' data-target='#modaldelete<?php echo e($user->id); ?>' class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                  </div>
                </td>
              </tr>
              <?php echo $__env->make('administrador.usuarios.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
</div>
<?php echo Form::open(['route'=>['administrador.usuarios.destroy',$user->id], 'method'=>'delete']); ?>

<div class="container">
    <div class="modal fade" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" id="modaldelete<?php echo e($user->id); ?>">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div id="eliminar" class="modal-header btn btn-danger">
                    <h4><i class="fas fa-trash"></i> Eliminar</h4>
                    <button class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <p>¿Esta seguro que desea eliminar el usuario <b><?php echo e($user->name); ?></b>  del sistema?</p>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-danger" type="submit"><i class="fas fa-thumbs-up"></i> Confirmar</button>
                    <button data-dismiss="modal" class="btn btn-primary"><i class="fas fa-ban"></i> Cancelar</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\inventarios-app\resources\views/administrador/usuarios/index.blade.php ENDPATH**/ ?>