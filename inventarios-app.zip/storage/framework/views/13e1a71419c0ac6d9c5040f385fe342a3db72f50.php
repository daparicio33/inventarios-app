
<?php $__env->startSection('title', 'Crear Item'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Registrar Movimiento</h1>
    <p>registrar el movimiento del inventario</p>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <?php echo $__env->make('inventarios.movimientos.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php echo Form::open(['route'=>'inventarios.movimientos.store','method'=>'post']); ?>   
<div class="row">
    
    <div class="col-sm-12 col-md-12 col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5>Datos</h5>
            </div>
            <div class="card-body">
             
                
                <?php if(isset($cliente)): ?> 
                    <input type="hidden" value="<?php echo e($cliente->idCliente); ?>" name="cliente_id">
                    <div class="row">
                        <div class="col-sm-12 col-md-4 col-lg-4">
                            <?php echo Form::label(null, 'Nombre', [null]); ?>

                            <?php echo Form::text('nombre', $cliente->nombre, ['class'=>'form-control']); ?>

                        </div>
                        <div class="col-sm-12 col-md-4 col-lg-4">
                            <?php echo Form::label(null, 'Apellido', [null]); ?>

                            <?php echo Form::text('apellido', $cliente->apellido, ['class'=>'form-control']); ?>

                        </div>
                        <div class="col-sm-12 col-md-4 col-lg-4">
                            <?php echo Form::label(null, 'Telefono', [null]); ?>

                            <?php echo Form::text('telefono', $cliente->telefono, ['class'=>'form-control']); ?>

                        </div>
                        <div class="col-sm-12 col-md-8 col-lg-8">
                            <?php echo Form::label(null, 'Direccion', [null]); ?>

                            <?php echo Form::text('direccion', $cliente->direccion, ['class'=>'form-control']); ?>

                        </div>
                        <div class="col-sm-12 col-md-4 col-lg-4">
                            <?php echo Form::label(null, 'Email', [null]); ?>

                            <?php echo Form::text('email', $cliente->email, ['class'=>'form-control']); ?>

                        </div>
                    </div>
                <?php endif; ?>
                
                <div class="row">
                    <div class="col-sm-12 col-md-3 col-lg-3">
                        <label for="">F Entrega</label>
                        <?php echo Form::date('fecha', null, ['class'=>'form-control']); ?>

                        <small class="text-danger"><?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                    </div>
                    <div class="col-sm-12 col-md-3 col-lg-3">
                        <label for="">F Regreso</label>
                        <?php echo Form::date('fdevolucion', null, ['class'=>'form-control']); ?>

                    </div>
                    <div class="col-sm-12 col-md-3 col-lg-3">
                        <label for="">Hora</label>
                        <?php echo Form::time('hora', null, ['class'=>'form-control']); ?>

                        <small class="text-danger"><?php $__errorArgs = ['hora'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                    </div>
                    <div class="col-sm-12 col-md-3 col-lg-3">
                        <label for="">T. Movimiento</label>
                        <?php echo Form::select('tmovimiento_id', $tmovimientos, 4, ['class'=>'form-control']); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-sm-12 col-md-12 col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5>Lista de Items</h5>
                <small class="text-danger"><?php $__errorArgs = ['items_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
            </div>
            <div class="card-body">
                <div class="input-group">
                    <button class="btn btn-outline-primary mb-1" id="add" onclick="agregar()" type="button">
                        <i class="fas fa-plus"></i>
                    </button>
                    <select id="dditems"  class="form-control" aria-label="Example select with button addon">
                      <option selected value="0">Elija...</option>
                      <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>:<?php echo e($item->url); ?>" ><?php echo e($item->codigo); ?> - <?php echo e($item->titem->nombre); ?> - <?php echo e($item->marca->nombre); ?> - <?php echo e($item->descripcion); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <table class="table">
                    <thead>
                        <tr>
                            <th style="width: 4rem"></th>
                            <th>ID</th>
                            <th>Descripcion</th>
                            <th>Cantidad</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="tbody">
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <button class="btn btn-primary" type="submit">
                    Guardar
                </button>
            </div>
        </div>
    </div>
</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            $('#dditems').select2();
        });
 
        function agregar(){
            //selecion del elemento
            var item = document.getElementById('dditems');
            //selection del texto
            var datos = item.value.split(':');
            var id = datos[0];
            var url = datos[1].split('/');
            if(document.getElementById('fila'+id)){
                var txt = document.getElementById('txt'+id);
                txt.value = parseInt(txt.value)+1;
            }else{
                var texto = item.options[item.selectedIndex].text;
                if (id == 0){
                    alert('selecione algun elemento');
                }else{
                    //selecciono el body de la tabla
                    var tbody = document.getElementById('tbody');
                    //creare una fila
                    var tr = document.createElement('tr');
                    tr.id = 'fila'+id;
                    //creare las columnas
                    var td0 = document.createElement('td');
                    var img = document.createElement('img');
                    img.src = '/storage/'+url[1]+'/'+url[2];
                    img.style.width = '4rem';
                    img.class = 'rounded mx-auto d-block';
                    td0.appendChild(img);
                    var td1 = document.createElement('td');
                    var td2 = document.createElement('td');
                    var td3 = document.createElement('td');
                    var td4 = document.createElement('td');

                    td1.appendChild(document.createTextNode(id));
                    //vamos a poner el texto con los id de los elementos agregados
                    var item_id = document.createElement('input');
                    item_id.type = 'hidden';
                    item_id.name = 'items_id[]';
                    item_id.value = id;
                    td1.appendChild(item_id);
                    td2.appendChild(document.createTextNode(texto));
                    //creamos cuadro de texto
                    var text = document.createElement('input');
                    text.type = 'number';
                    text.id = 'txt'+id;
                    text.setAttribute('class','form-control');
                    text.value = 1;
                    text.name = "cantidad[]";  
                    td3.appendChild(text);
                    td3.setAttribute('style','width: 15%');
                    //creamos el boton de elminar
                    var btn = document.createElement('a')
                    var i = document.createElement('i');
                    i.setAttribute('class','fas fa-trash')
                    btn.appendChild(i);
                    btn.setAttribute('class','btn btn-danger')
                    btn.title= 'eliminar elemento';
                    btn.setAttribute('onclick','deleterow('+id+')');
                    td4.appendChild(btn);
                    tr.appendChild(td0);
                    tr.appendChild(td1);
                    tr.appendChild(td2);
                    tr.appendChild(td3);
                    tr.appendChild(td4);
                    tbody.appendChild(tr);
                }
            }
        }
        function deleterow(id){
            document.getElementById('fila'+id).remove();
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\inventarios-app\resources\views/inventarios/movimientos/create.blade.php ENDPATH**/ ?>