
<?php $__env->startSection('title'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Tipos de movimientos existentes</h1>
    <a href="<?php echo e(route('inventarios.movimientos.tmovimientos.create')); ?>">
        <button class="btn btn-primary"> 
            <i class="fas fa-folder-open"></i> Crear nuevo tipo
        </button>
    </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <table class="table">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Factor</th>
                <th>Administrador</th>
            </tr>
        </thead>
        <tbody>
                <?php $__currentLoopData = $tmovimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tmovimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($tmovimiento->nombre); ?></td>
                    <td><?php echo e($tmovimiento->factor); ?></td>
                    <td><?php echo e($tmovimiento->administrador); ?></td>
                    <td>
                        <a href="<?php echo e(route('inventarios.movimientos.tmovimientos.edit', $tmovimiento->id)); ?>">
                            <button class="btn btn-primary">
                                <i class="far fa-edit"></i> Editar
                            </button>
                        </a>
                        <a data-toggle="modal" data-target="#modal-delete-<?php echo e($tmovimiento->id); ?>">
                            <button class="btn btn-danger">
                                <i class="fas fa-trash-alt"></i> Eliminar
                            </button>
                        </a>
                    </td>
                </tr>
                <?php echo $__env->make('inventarios.movimientos.tmovimientos.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\inventarios-app\resources\views/inventarios/movimientos/tmovimientos/index.blade.php ENDPATH**/ ?>