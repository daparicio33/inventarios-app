
<?php $__env->startSection('title', 'Movimientos'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Movimientos de Almacen</h1>
    <a href="<?php echo e(route('inventarios.movimientos.create')); ?>">
        <button class="btn btn-primary"> 
            <i class="fas fa-paper-plane"></i> Nuevo
        </button>
    </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="table-responsive">
    <table class="table" style="white-space: nowrap; overflow-x: auto;">
        <thead>
            <tr>
                <th>#</th>
                <th>Tipo</th>
                <th>Fecha</th>
                <th>Hora</th>
                <th>Cliente</th>
                <th>Usuario</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $movimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($movimiento->numero); ?></td>
                    <td><?php echo e($movimiento->tmovimiento->nombre); ?></td>
                    <td><?php echo e(date('d-M-Y',strtotime($movimiento->fecha))); ?></td>
                    <td><?php echo e($movimiento->hora); ?></td>
                    <td>Nombre de Cliente</td>
                    <td>correo@idexperujapon.edu.pe</td>
                    <td style="text-align: center; width: 160px">
                        <a data-toggle="modal" data-target="#modal-mostrar-<?php echo e($movimiento->id); ?>"  title="mostrar" class="btn btn-info btn-sm">
                            <i class="fas fa-eye"></i>
                        </a>
                        <a href="" class="btn btn-warning btn-sm" title="imprimir">
                            <i class="fas fa-print"></i>
                        </a>
                        <a data-toggle="modal" data-target="#modal-delete-<?php echo e($movimiento->id); ?>" class="btn btn-danger btn-sm" title="eliminar">
                            <i class="fas fa-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php echo $__env->make('inventarios.movimientos.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\inventarios-app\resources\views/almacenero/index.blade.php ENDPATH**/ ?>