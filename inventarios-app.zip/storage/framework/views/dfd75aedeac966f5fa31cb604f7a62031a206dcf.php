
<?php $__env->startSection('title', 'Existencias'); ?>
<?php $__env->startSection('content_header'); ?>
<h1>Existencias del Inventario</h1>
<?php if (isset($component)) { $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Navbar::class, ['activo' => 'perdidas']); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c)): ?>
<?php $component = $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c; ?>
<?php unset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h5>Lista de Items con sus existencias</h5>
    </div>
    <div class="card-body">
        <table class="table">
            <thead>
                <tr>
                    <th>Codigo</th>
                    <th>Descripción</th>
                    <th>Marca</th>
                    <th>Tipo</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr <?php if(count($item->hijos) != 0): ?> class="bg-info" <?php endif; ?>>
                        <td><?php echo e($item->codigo); ?></td>
                        <td><?php echo e($item->descripcion); ?> <span class="badge bg-danger rounded-pill"><?php echo e(count($item->hijos)); ?> Items</span></td>
                        <td><?php echo e($item->marca->nombre); ?></td>
                        <td><?php echo e($item->titem->nombre); ?></td>
                        <td>
                            <span class="badge bg-secondary rounded-pill">perdidas en el almacen <?php echo e(perdidas($item->id)); ?></span>
                        </td>
                    </tr>
                    <?php if(count($item->hijos) != 0): ?> 
                            <tr>
                                <td></td>
                                <td colspan="3">
                                    <ol class="list-group list-group-numbered">
                                        <?php $__currentLoopData = $item->hijos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hijo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item"><?php echo e($hijo->codigo); ?> - <?php echo e($hijo->descripcion); ?> <span class="badge bg-primary rounded-pill">perdidas en el <?php echo e(perdidas($hijo->id)); ?></span></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ol>   
                                </td>
                            </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\inventarios-app\resources\views/inventarios/existencias/perdidas.blade.php ENDPATH**/ ?>