<!-- Modal -->
<?php echo Form::open(['route'=>['administrador.almacenes.encargados.destroy',$encargado->id],'method'=>'delete']); ?>

<div class="modal fade" id="modal-delete-<?php echo e($encargado->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title fas fa-exclamation text-danger" id="exampleModalLabel"> Confirmar accion</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body text-left">
          <p>Esta seguro que desea eliminar al encargado <b><?php echo e($encargado->user->name); ?></b> con cargo <b><?php echo e($encargado->cargo->nombre); ?></b> en el almacen <b><?php echo e($encargado->almacene->nombre); ?></b></p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fas fa-ban"></i> Cancelar</button>
          <button type="submit" class="btn btn-danger"><i class="fas fa-check"></i> Confirmar</button>
        </div>
      </div>
    </div>
  </div>
  <?php echo Form::close(); ?><?php /**PATH C:\Users\Dave\Desktop\inventarios-app\resources\views/administrador/almacenes/encargados/modal.blade.php ENDPATH**/ ?>