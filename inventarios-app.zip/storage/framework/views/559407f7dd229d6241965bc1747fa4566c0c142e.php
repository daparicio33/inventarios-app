
<?php $__env->startSection('title', 'Lista: Marcas'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Tipos de marcas existentes</h1>
    <a href="<?php echo e(route('inventarios.marcas.create')); ?>">
        <button class="btn btn-primary"> 
            <i class="fas fa-folder-open"></i> Crear nueva marca
        </button>
    </a>
    <?php echo $__env->make('layouts.info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<table class="table">
    <thead>
        <tr>
          <th>Nombre</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($marca->nombre); ?></td>
                <td>
                <a href="<?php echo e(route('inventarios.marcas.edit', $marca->id)); ?>">
                    <button class="btn btn-primary">
                        <i class="far fa-edit"></i> Editar
                    </button>
                </a>
                <a data-toggle="modal" data-target="#modal-delete-<?php echo e($marca->id); ?>">
                    <button class="btn btn-danger">
                        <i class="fas fa-trash-alt"></i> Eliminar
                    </button>
                </a>
                </td>
            </tr>
            <?php echo $__env->make('inventarios.marcas.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\inventarios-app\resources\views/inventarios/marcas/index.blade.php ENDPATH**/ ?>