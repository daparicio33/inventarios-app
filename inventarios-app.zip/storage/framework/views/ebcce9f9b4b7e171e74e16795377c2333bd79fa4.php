
<?php $__env->startSection('title', 'Tipos de Items'); ?>
<?php $__env->startSection('content_header'); ?>
    <h2>Tipos de Items</h2>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<style>
    .td{
        width: 80%;
        text-align: left;
    }
    .td i{
        margin-right: 7px;
    }
    .td1{
        width:5%;
        text-align: center;
    }
    h3{
        font-family: BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        color: rgba(17, 17, 199, 0.726);
    }
    button{
        margin-bottom: 10px;
        margin-top: 3px;
    }
    label{
        font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
    }
    #crear{
        color: white;
    }
    #editar{
        color: white; }
    #eliminar{
        color: white;
    }
    #nuevo{
        margin-bottom: 20px;
    }
</style>
<div class="container">
    <div class="row">
        <div class="col-sm-6 col-lg-12">
            <button id="nuevo" class="btn btn-primary" type="button" data-toggle='modal' data-target='#modalcreate' ><i class="fas fa-plus"></i>
            Nuevo Tipo de Item</button>    
            
        </div>    
    </div>       
</div>
<?php echo $__env->make('inventarios.titems.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-6 col-lg-12">
            <div>
                <table class="table" style="width: 100%">
                    <thead class="text-center">
                        <tr>
                            <th class="td1"><i class="fas fa-list-ol"></i></th>
                            <th class="td"><i class="fas fa-toolbox"></i>Nombre</th>
                            <th>Opciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $titems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $titem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($titem->id); ?></td>
                                <td><?php echo e($titem->nombre); ?></td>
                                <td>
                                    <div class="btn-group">
                                        <button type="button" data-toggle='modal' data-target='#modaledit<?php echo e($titem->id); ?>' class="btn btn-primary"><i class="fas fa-pen"></i></button>
                                        <button type="button" data-toggle='modal' data-target='#modaldelete<?php echo e($titem->id); ?>' class="btn btn-danger"><i class="fas fa-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                            <?php echo $__env->make('inventarios.titems.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('inventarios.titems.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<body>


</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\inventarios-app\resources\views/inventarios/titems/index.blade.php ENDPATH**/ ?>