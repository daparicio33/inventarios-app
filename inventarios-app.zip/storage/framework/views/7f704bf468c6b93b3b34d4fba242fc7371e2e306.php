
<?php $__env->startSection('title', 'Nuevo almacen'); ?>
<?php $__env->startSection('content_header'); ?>
<h1>Crear un almacen</h1>
<?php echo Form::open(['route'=>['administrador.almacenes.store'], 'method'=>'post']); ?>

<div class="row mt-2">
    <div class="col-sm-12 col-lg-6">
        <div class="card">
            <div class="card-header">
                <h5>Datos del Almacen</h5>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label for="">Nombre</label>
                    <?php echo Form::text('nombre', null, ['class'=>'form-control']); ?>

                    <label for="">Observación</label>
                    <?php echo Form::text('observacion', null, ['class'=>'form-control']); ?>

                </div>
            </div>
            <div class="card-footer">
            <button type="submit" class="btn btn-primary" style="margin: 7px">
                <i class="fas fa-save"></i> Guardar
            </button>
            </div>
        </div>
    </div>
</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\inventarios-app\resources\views/administrador/almacenes/create.blade.php ENDPATH**/ ?>