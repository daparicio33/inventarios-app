<?php if(session('info')): ?>
    <div class="alert alert-success mt-3" id='info'>
        <strong><?php echo e(session('info')); ?></strong>
    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger mt-3" id='error'>
        <strong><?php echo e(session('error')); ?></strong>
    </div>
<?php endif; ?><?php /**PATH C:\Users\Dave\Desktop\inventarios-app\resources\views/layouts/info.blade.php ENDPATH**/ ?>