
<?php $__env->startSection('title', 'Items'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Items</h1>
    <a href="<?php echo e(route('inventarios.items.create')); ?>">
        <button class="btn btn-primary"> 
            <i class="fas fa-folder-open"></i> Nuevo Item
        </button>
    </a>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <p>Lista de Items del sistema.</p>
    <table class="table">
        <thead>
            <tr>
                <th>Codigo</th>
                <th>Descripción</th>
                <th>Marca</th>
                <th>Tipo</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr <?php if(count($item->hijos) != 0): ?> class="bg-info" <?php endif; ?>>
                    <td><?php echo e($item->codigo); ?></td>
                    <td><?php echo e($item->descripcion); ?> <span class="badge bg-danger rounded-pill"><?php echo e(count($item->hijos)); ?> items</span></td>
                    <td><?php echo e($item->marca->nombre); ?></td>
                    <td><?php echo e($item->titem->nombre); ?></td>
                    <td>
                        
                        <a class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-imagen-<?php echo e($item->id); ?>">
                            <i class="far fa-eye"></i>
                        </a>
                        <a href="<?php echo e(route('inventarios.items.edit',$item->id)); ?>" class="btn btn-success btn-sm">
                            <i class="far fa-edit"></i>
                        </a>
                        <a class="btn btn-danger btn-sm" data-toggle="modal" data-target="#modal-delete-<?php echo e($item->id); ?>">
                            <i class="fas fa-trash-alt"></i>
                        </a>
                    </td>
                </tr>
                <?php if(count($item->hijos) != 0): ?>
                        <tr>
                            <td></td>
                            <td colspan="4">
                                <ol class="list-group list-group-numbered">
                                    <?php $__currentLoopData = $item->hijos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hijo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item">
                                            <div class="row">
                                                <div class="col-sm-12 col-md-10 col-lg-10">
                                                    <?php echo e($hijo->codigo); ?> - <?php echo e($hijo->descripcion); ?>

                                                </div>
                                                <div class="col-sm-12 col-md-2 col-lg-2">
                                                    <a class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-imagen-<?php echo e($hijo->id); ?>">
                                                        <i class="far fa-eye"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('inventarios.items.edit',$hijo->id)); ?>" class="btn btn-success btn-sm">
                                                       <i class="far fa-edit"></i>
                                                    </a>
                                                    <a class="btn btn-danger btn-sm" data-toggle="modal" data-target="#modal-delete-<?php echo e($hijo->id); ?>">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </li>
                                        <?php echo $__env->make('inventarios.items.modal1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ol>
                            </td>
                        </tr>
                <?php endif; ?>
                <?php echo $__env->make('inventarios.items.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\inventarios-app\resources\views/inventarios/items/index.blade.php ENDPATH**/ ?>