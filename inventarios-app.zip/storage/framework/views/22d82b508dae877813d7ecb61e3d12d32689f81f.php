<ul class="nav active bg-light rounded border border-info mt-2 mb-2">
    <li class="nav-item">
        <a class="nav-link btn btn-light active" href="<?php echo e(route('inventarios.existencias.index')); ?>">
            <i class="fas fa-door-open"></i> Existencias
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link btn btn-light" href="<?php echo e(route('inventarios.existencias.show','ingresos')); ?>">
            <i class="fas fa-share-square"></i> Ingresos
        </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">Link</a>
    </li>
    <li class="nav-item">
      <a class="nav-link disabled">Disabled</a>
    </li>
</ul> <?php /**PATH C:\Users\Dave\Desktop\inventarios-app\resources\views/inventarios/existencias/nav.blade.php ENDPATH**/ ?>