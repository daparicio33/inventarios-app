<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(ceros($movimiento->numero)); ?></title>
    <style >
        td p{
            margin: 0;
        }
        .badge{
            background-color: rgb(42, 92, 152);
            color: #fff;
            display: inline-block;
            padding-left: 8px;
            padding-right: 8px;
            text-align: center;
            border-radius: 7px;
        }
        h3{
            padding: 0px;
            margin: 0px;
        }
        .separador{
            background-color: rgb(68, 119, 164);
            color: #fff;
            border: 2px solid rgb(4, 33, 74);
        }
        .contenido{
            border: 2px solid rgb(4, 33, 74);
        }
        h2{
            text-align: center;
            margin: 0;
            text-transform: uppercase;
        }
        p{
            font-size: 13px;
        }
    </style>
</head>
<body>
    <table style="width: 100%">
        <tr>
            <td style="width: 50% ; border: 3px solid black" >
                <table>
                    <tr>
                        <td style="width: 80%">
                            <h2 ><?php echo e($movimiento->tmovimiento->nombre); ?></h2>
                        </td>
                        <td>
                            <p>
                                <b>Fecha: </b><?php echo e(date('d-m-Y',strtotime($movimiento->fecha))); ?>

                            </p>
                            <p>
                                <b>Hora: </b><?php echo e(date('h:i:s A',strtotime($movimiento->hora))); ?>

                            </p>
                            <p>
                                <b>Número: </b><?php echo e(ceros($movimiento->numero)); ?>

                            </p> 
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" class="separador"><h3>1. Datos del Solicitante</h3></td>
                    </tr>
                    <tr>
                        <td colspan="2" class="contenido">
                            <table style="width: 100%" >
                                <tr>
                                    <td style="width: 30%"><b>Apellidos,</b> Nombres</td>
                                    <td style="border: 1px solid black"><b><?php echo e($movimiento->cliente->apellido); ?>,</b> <?php echo e($movimiento->cliente->nombre); ?></td>
                                </tr>
                                <tr>
                                    <td style="width: 30%"><b>DNI</b></td>
                                    <td style="border: 1px solid black"><b><?php echo e($movimiento->cliente->dniRuc); ?></b></td>
                                </tr>
                            </table>
                        </td> 
                    </tr>
                    <tr>
                        <td colspan="2" class="separador"><h3>2. Datos del Almacenero</h3></td>
                    </tr>
                    <tr>
                        <td colspan="2" class="contenido">
                            <table style="width: 100%">
                                <tr>
                                    <td style="width: 30%"><b>Nombres</b></td>
                                    <td style="border: 1px solid black"><?php echo e($movimiento->user->name); ?></td>
                                </tr>
                                <tr>
                                    <td style="width: 30%"><b>Correo</b></td>
                                    <td style="border: 1px solid black"><?php echo e($movimiento->user->email); ?></td>
                                </tr>
                            </table>
                        </td> 
                    </tr>
                    <tr>
                        <td colspan="2" class="separador"><h3>3. Lista de Items</h3></td>
                    </tr>
                    <tr>
                        <td colspan="2" class="contenido">
                            <table style="width: 100%">
                                <thead>
                                    <tr style="text-align: left">
                                        <th>Codigo</th>
                                        <th>Cantidad</th>
                                        <th>Descripción</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $movimiento->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($detalle->item->item_id == null): ?>                                    
                                        <tr <?php if(count($detalle->item->hijos) != 0): ?> class="bg-info" <?php endif; ?>>
                                            <td><?php echo e($detalle->item->codigo); ?></td>
                                            <td><?php echo e($detalle->cantidad); ?></td>
                                            <td><?php echo e($detalle->item->titem->nombre); ?> - <?php echo e($detalle->item->marca->nombre); ?> - <?php echo e($detalle->item->descripcion); ?> <span class="badge"><?php echo e(count($detalle->item->hijos)); ?> items</span></td>
                                        </tr>
                                        <?php if(count($detalle->item->hijos) != 0): ?>
                                                <tr>
                                                    <td></td>
                                                    <td colspan="4">
                                                        <ul style="margin: 0px">
                                                            <?php $__currentLoopData = $detalle->item->hijos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hijo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li class="list-group-item">
                                                                    <div class="row">
                                                                        <div class="col-sm-12 col-md-12 col-lg-12">
                                                                            <?php echo e($hijo->codigo); ?> - <?php echo e($detalle->cantidad); ?> - <?php echo e($hijo->descripcion); ?>

                                                                        </div>
                                                                    </div>
                                                                </li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    </td>
                                                </tr>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </td> 
                    </tr>
                    <tr>
                        <td colspan="2" class="separador"><h3>4. Firmas</h3></td>
                    </tr>
                    <tr>
                        <td colspan="2" class="contenido">
                            <table style="width: 100%; margin-top: 50px">
                                <tr style="text-align: center">
                                    <td style="width: 50%"><b>_____________</b></td>
                                    <td style="width: 50%"><b>_____________</b></td>
                                </tr>
                                <tr style="text-align: center">
                                    <td style="width: 50%"><b>Solicitante</b></td>
                                    <td style="width: 50%"><b>Almacenero</b></td>
                                </tr>
                            </table>
                        </td> 
                    </tr>
                </table>
            </td>
            <td style="width: 50% ; border: 3px solid black" >
                <table>
                    <tr>
                        <td style="width: 80%">
                            <h2 ><?php echo e($movimiento->tmovimiento->nombre); ?></h2>
                        </td>
                        <td>
                            <p>
                                <b>Fecha: </b><?php echo e(date('d-m-Y',strtotime($movimiento->fecha))); ?>

                            </p>
                            <p>
                                <b>Hora: </b><?php echo e(date('h:i:s A',strtotime($movimiento->hora))); ?>

                            </p>
                            <p>
                                <b>Número: </b><?php echo e(ceros($movimiento->numero)); ?>

                            </p> 
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" class="separador"><h3>1. Datos del Solicitante</h3></td>
                    </tr>
                    <tr>
                        <td colspan="2" class="contenido">
                            <table style="width: 100%" >
                                <tr>
                                    <td style="width: 30%"><b>Apellidos,</b> Nombres</td>
                                    <td style="border: 1px solid black"><b><?php echo e($movimiento->cliente->apellido); ?>,</b> <?php echo e($movimiento->cliente->nombre); ?></td>
                                </tr>
                                <tr>
                                    <td style="width: 30%"><b>DNI</b></td>
                                    <td style="border: 1px solid black"><b><?php echo e($movimiento->cliente->dniRuc); ?></b></td>
                                </tr>
                            </table>
                        </td> 
                    </tr>
                    <tr>
                        <td colspan="2" class="separador"><h3>2. Datos del Almacenero</h3></td>
                    </tr>
                    <tr>
                        <td colspan="2" class="contenido">
                            <table style="width: 100%">
                                <tr>
                                    <td style="width: 30%"><b>Nombres</b></td>
                                    <td style="border: 1px solid black"><?php echo e($movimiento->user->name); ?></td>
                                </tr>
                                <tr>
                                    <td style="width: 30%"><b>Correo</b></td>
                                    <td style="border: 1px solid black"><?php echo e($movimiento->user->email); ?></td>
                                </tr>
                            </table>
                        </td> 
                    </tr>
                    <tr>
                        <td colspan="2" class="separador"><h3>3. Lista de Items</h3></td>
                    </tr>
                    <tr>
                        <td colspan="2" class="contenido">
                            <table style="width: 100%">
                                <thead>
                                    <tr style="text-align: left">
                                        <th>Codigo</th>
                                        <th>Cantidad</th>
                                        <th>Descripción</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $movimiento->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($detalle->item->item_id == null): ?> 
                                        <tr <?php if(count($detalle->item->hijos) != 0): ?> class="bg-info" <?php endif; ?>>
                                            <td><?php echo e($detalle->item->codigo); ?></td>
                                            <td><?php echo e($detalle->cantidad); ?></td>
                                            <td><?php echo e($detalle->item->titem->nombre); ?> - <?php echo e($detalle->item->marca->nombre); ?> - <?php echo e($detalle->item->descripcion); ?> <span class="badge"><?php echo e(count($detalle->item->hijos)); ?> items</span></td>
                                        </tr>
                                        <?php if(count($detalle->item->hijos) != 0): ?>
                                            <tr>
                                                <td></td>
                                                <td colspan="4">
                                                    <ul style="margin: 0px">
                                                        <?php $__currentLoopData = $detalle->item->hijos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hijo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li class="list-group-item">
                                                                <div class="row">
                                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                                        <?php echo e($hijo->codigo); ?> - <?php echo e($detalle->cantidad); ?> - <?php echo e($hijo->descripcion); ?>

                                                                    </div>
                                                                </div>
                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </td> 
                    </tr>
                    <tr>
                        <td colspan="2" class="separador"><h3>4. Firmas</h3></td>
                    </tr>
                    <tr>
                        <td colspan="2" class="contenido">
                            <table style="width: 100%; margin-top: 50px">
                                <tr style="text-align: center">
                                    <td style="width: 50%"><b>_____________</b></td>
                                    <td style="width: 50%"><b>_____________</b></td>
                                </tr>
                                <tr style="text-align: center">
                                    <td style="width: 50%"><b>Solicitante</b></td>
                                    <td style="width: 50%"><b>Almacenero</b></td>
                                </tr>
                            </table>
                        </td> 
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html><?php /**PATH C:\Users\Dave\Desktop\inventarios-app\resources\views/almaceneros/imprimir.blade.php ENDPATH**/ ?>